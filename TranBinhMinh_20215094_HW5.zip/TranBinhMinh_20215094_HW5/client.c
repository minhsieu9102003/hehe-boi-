// client.c

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <ctype.h>

#ifdef _WIN32
    #define _CRT_SECURE_NO_WARNINGS
    #include <winsock2.h>
    #include <ws2tcpip.h>
    
#else
    #include <unistd.h>
    #include <arpa/inet.h>
    #include <netinet/in.h>
    #include <sys/socket.h>
#endif

#define BUFFER_SIZE 1024

int main(int argc, char *argv[]) {
    #ifdef _WIN32
        WSADATA wsaData;
        int iResult;
    #endif

    if (argc != 3) {
        printf("Usage: %s IPAddress PortNumber\n", argv[0]);
        exit(EXIT_FAILURE);
    }

    int client_sock;
    int port_number;
    struct sockaddr_in server_addr;
    char buffer[BUFFER_SIZE];
    socklen_t addr_len = sizeof(server_addr);

    port_number = atoi(argv[2]);

    #ifdef _WIN32
        iResult = WSAStartup(MAKEWORD(2,2), &wsaData);
        if (iResult != 0) {
            printf("WSAStartup failed: %d\n", iResult);
            exit(EXIT_FAILURE);
        }
    #endif

    // Create UDP socket
    #ifdef _WIN32
        client_sock = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
        if (client_sock == INVALID_SOCKET) {
            printf("Cannot create socket: %d\n", WSAGetLastError());
            WSACleanup();
            exit(EXIT_FAILURE);
        }
    #else
        client_sock = socket(AF_INET, SOCK_DGRAM, 0);
        if (client_sock < 0) {
            perror("Cannot create socket");
            exit(EXIT_FAILURE);
        }
    #endif

    // Server address
    memset(&server_addr, 0, sizeof(server_addr));
    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(port_number);

    #ifdef _WIN32
        server_addr.sin_addr.s_addr = inet_addr(argv[1]);
        if (server_addr.sin_addr.s_addr == INADDR_NONE) {
            printf("Invalid IP address\n");
            closesocket(client_sock);
            WSACleanup();
            exit(EXIT_FAILURE);
        }
    #else
        if (inet_pton(AF_INET, argv[1], &server_addr.sin_addr) <= 0) {
            printf("Invalid address\n");
            close(client_sock);
            exit(EXIT_FAILURE);
        }
    #endif

    char username[50], password[50];

    printf("Insert username: ");
    fgets(username, sizeof(username), stdin);
    username[strcspn(username, "\n")] = '\0';

    printf("Insert password: ");
    fgets(password, sizeof(password), stdin);
    password[strcspn(password, "\n")] = '\0';

    // Send username
    #ifdef _WIN32
        sendto(client_sock, username, strlen(username) + 1, 0,
               (struct sockaddr *)&server_addr, addr_len);
    #else
        sendto(client_sock, username, strlen(username) + 1, 0,
               (struct sockaddr *)&server_addr, addr_len);
    #endif

    // Send password
    #ifdef _WIN32
        sendto(client_sock, password, strlen(password) + 1, 0,
               (struct sockaddr *)&server_addr, addr_len);
    #else
        sendto(client_sock, password, strlen(password) + 1, 0,
               (struct sockaddr *)&server_addr, addr_len);
    #endif

    // Receive response
    memset(buffer, 0, BUFFER_SIZE);
    #ifdef _WIN32
        int recv_len = recvfrom(client_sock, buffer, BUFFER_SIZE, 0,
                                (struct sockaddr *)&server_addr, &addr_len);
        if (recv_len == SOCKET_ERROR) {
            printf("recvfrom() failed: %d\n", WSAGetLastError());
            closesocket(client_sock);
            WSACleanup();
            exit(EXIT_FAILURE);
        }
    #else
        if (recvfrom(client_sock, buffer, BUFFER_SIZE, 0,
                     (struct sockaddr *)&server_addr, &addr_len) < 0) {
            perror("recvfrom() failed");
            close(client_sock);
            exit(EXIT_FAILURE);
        }
    #endif

    printf("%s\n", buffer);

    if (strcmp(buffer, "OK") != 0) {
        #ifdef _WIN32
            closesocket(client_sock);
            WSACleanup();
        #else
            close(client_sock);
        #endif
        exit(EXIT_FAILURE);
    }

    // Post-login operations
    while (1) {
        printf("Enter new password or 'bye' to sign out: ");
        fgets(buffer, BUFFER_SIZE, stdin);
        buffer[strcspn(buffer, "\n")] = '\0';

        if (strlen(buffer) == 0)
            continue;

        // Send message to server
        #ifdef _WIN32
            sendto(client_sock, buffer, strlen(buffer) + 1, 0,
                   (struct sockaddr *)&server_addr, addr_len);
        #else
            sendto(client_sock, buffer, strlen(buffer) + 1, 0,
                   (struct sockaddr *)&server_addr, addr_len);
        #endif

        // Receive response
        memset(buffer, 0, BUFFER_SIZE);
        #ifdef _WIN32
            recv_len = recvfrom(client_sock, buffer, BUFFER_SIZE, 0,
                                (struct sockaddr *)&server_addr, &addr_len);
            if (recv_len == SOCKET_ERROR) {
                printf("recvfrom() failed: %d\n", WSAGetLastError());
                break;
            }
        #else
            if (recvfrom(client_sock, buffer, BUFFER_SIZE, 0,
                         (struct sockaddr *)&server_addr, &addr_len) < 0) {
                perror("recvfrom() failed");
                break;
            }
        #endif

        printf("%s\n", buffer);

        if (strncmp(buffer, "Goodbye", 7) == 0)
            break;
    }

    // Close socket
    #ifdef _WIN32
        closesocket(client_sock);
        WSACleanup();
    #else
        close(client_sock);
    #endif

    return 0;
}
