// server.c

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <ctype.h>

#ifdef _WIN32
    #define _CRT_SECURE_NO_WARNINGS
    #include <winsock2.h>
    #include <ws2tcpip.h>
    
#else
    #include <unistd.h>
    #include <arpa/inet.h>
    #include <netinet/in.h>
    #include <sys/socket.h>
#endif

#include "sha256.h"

#define MAX_ACCOUNTS 100
#define BUFFER_SIZE 1024

typedef struct {
    char username[50];
    char password[50];
    int status; // 0: blocked/not activated, 1: active
    int fail_attempts;
} Account;

Account accounts[MAX_ACCOUNTS];
int account_count = 0;

void load_accounts() {
    FILE *file = fopen("account.txt", "r");
    if (!file) {
        perror("Failed to open account.txt");
        exit(EXIT_FAILURE);
    }

    while (fscanf(file, "%s %s %d", accounts[account_count].username,
                  accounts[account_count].password,
                  &accounts[account_count].status) != EOF) {
        accounts[account_count].fail_attempts = 0;
        account_count++;
    }
    fclose(file);
}

void save_accounts() {
    FILE *file = fopen("account.txt", "w");
    if (!file) {
        perror("Failed to open account.txt");
        exit(EXIT_FAILURE);
    }

    for (int i = 0; i < account_count; i++) {
        fprintf(file, "%s %s %d\n", accounts[i].username,
                accounts[i].password, accounts[i].status);
    }
    fclose(file);
}

Account* find_account(char *username) {
    for (int i = 0; i < account_count; i++) {
        if (strcmp(accounts[i].username, username) == 0)
            return &accounts[i];
    }
    return NULL;
}

int is_alphanumeric(const char *str) {
    while (*str) {
        if (!isalnum((unsigned char)*str))
            return 0;
        str++;
    }
    return 1;
}

int main(int argc, char *argv[]) {
    #ifdef _WIN32
        WSADATA wsaData;
        int iResult;
    #endif

    if (argc != 2) {
        printf("Usage: %s PortNumber\n", argv[0]);
        exit(EXIT_FAILURE);
    }

    int server_sock;
    int port_number;
    struct sockaddr_in server_addr, client_addr;
    char buffer[BUFFER_SIZE];
    socklen_t addr_len = sizeof(client_addr);

    port_number = atoi(argv[1]);

    #ifdef _WIN32
        iResult = WSAStartup(MAKEWORD(2,2), &wsaData);
        if (iResult != 0) {
            printf("WSAStartup failed: %d\n", iResult);
            exit(EXIT_FAILURE);
        }
    #endif

    load_accounts();

    // Create UDP socket
    #ifdef _WIN32
        server_sock = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
        if (server_sock == INVALID_SOCKET) {
            printf("Cannot create socket: %d\n", WSAGetLastError());
            WSACleanup();
            exit(EXIT_FAILURE);
        }
    #else
        server_sock = socket(AF_INET, SOCK_DGRAM, 0);
        if (server_sock < 0) {
            perror("Cannot create socket");
            exit(EXIT_FAILURE);
        }
    #endif

    // Bind socket to port
    memset(&server_addr, 0, sizeof(server_addr));
    server_addr.sin_family = AF_INET;
    #ifdef _WIN32
        server_addr.sin_addr.s_addr = INADDR_ANY;
    #else
        server_addr.sin_addr.s_addr = htonl(INADDR_ANY);
    #endif
    server_addr.sin_port = htons(port_number);

    #ifdef _WIN32
        if (bind(server_sock, (struct sockaddr *)&server_addr, sizeof(server_addr)) == SOCKET_ERROR) {
            printf("Bind failed: %d\n", WSAGetLastError());
            closesocket(server_sock);
            WSACleanup();
            exit(EXIT_FAILURE);
        }
    #else
        if (bind(server_sock, (struct sockaddr *)&server_addr, sizeof(server_addr)) < 0) {
            perror("Bind failed");
            close(server_sock);
            exit(EXIT_FAILURE);
        }
    #endif

    printf("Server is running on port %d\n", port_number);

    while (1) {
        char username[50], password[50];
        Account *account = NULL;

        // Receive username
        memset(username, 0, sizeof(username));
        #ifdef _WIN32
            int recv_len = recvfrom(server_sock, username, sizeof(username), 0,
                                    (struct sockaddr *)&client_addr, &addr_len);
            if (recv_len == SOCKET_ERROR) {
                printf("recvfrom() failed: %d\n", WSAGetLastError());
                continue;
            }
        #else
            if (recvfrom(server_sock, username, sizeof(username), 0,
                         (struct sockaddr *)&client_addr, &addr_len) < 0) {
                perror("recvfrom() failed");
                continue;
            }
        #endif

        // Receive password
        memset(password, 0, sizeof(password));
        #ifdef _WIN32
            recv_len = recvfrom(server_sock, password, sizeof(password), 0,
                                (struct sockaddr *)&client_addr, &addr_len);
            if (recv_len == SOCKET_ERROR) {
                printf("recvfrom() failed: %d\n", WSAGetLastError());
                continue;
            }
        #else
            if (recvfrom(server_sock, password, sizeof(password), 0,
                         (struct sockaddr *)&client_addr, &addr_len) < 0) {
                perror("recvfrom() failed");
                continue;
            }
        #endif

        account = find_account(username);

        if (account == NULL) {
            char *msg = "Account not found";
            #ifdef _WIN32
                sendto(server_sock, msg, strlen(msg) + 1, 0,
                       (struct sockaddr *)&client_addr, addr_len);
            #else
                sendto(server_sock, msg, strlen(msg) + 1, 0,
                       (struct sockaddr *)&client_addr, addr_len);
            #endif
            continue;
        }

        if (strcmp(account->password, password) == 0) {
            if (account->status == 1) {
                char *msg = "OK";
                #ifdef _WIN32
                    sendto(server_sock, msg, strlen(msg) + 1, 0,
                           (struct sockaddr *)&client_addr, addr_len);
                #else
                    sendto(server_sock, msg, strlen(msg) + 1, 0,
                           (struct sockaddr *)&client_addr, addr_len);
                #endif
            } else {
                char *msg = "Account not ready";
                #ifdef _WIN32
                    sendto(server_sock, msg, strlen(msg) + 1, 0,
                           (struct sockaddr *)&client_addr, addr_len);
                #else
                    sendto(server_sock, msg, strlen(msg) + 1, 0,
                           (struct sockaddr *)&client_addr, addr_len);
                #endif
            }
        } else {
            account->fail_attempts++;
            if (account->fail_attempts >= 3) {
                account->status = 0; // Block the account
                save_accounts();
                char *msg = "Account is blocked";
                #ifdef _WIN32
                    sendto(server_sock, msg, strlen(msg) + 1, 0,
                           (struct sockaddr *)&client_addr, addr_len);
                #else
                    sendto(server_sock, msg, strlen(msg) + 1, 0,
                           (struct sockaddr *)&client_addr, addr_len);
                #endif
            } else {
                char *msg = "Not OK";
                #ifdef _WIN32
                    sendto(server_sock, msg, strlen(msg) + 1, 0,
                           (struct sockaddr *)&client_addr, addr_len);
                #else
                    sendto(server_sock, msg, strlen(msg) + 1, 0,
                           (struct sockaddr *)&client_addr, addr_len);
                #endif
            }
            continue;
        }

        // Handle post-login operations
        while (1) {
            memset(buffer, 0, BUFFER_SIZE);
            #ifdef _WIN32
                recv_len = recvfrom(server_sock, buffer, BUFFER_SIZE, 0,
                                    (struct sockaddr *)&client_addr, &addr_len);
                if (recv_len == SOCKET_ERROR) {
                    printf("recvfrom() failed: %d\n", WSAGetLastError());
                    break;
                }
            #else
                if (recvfrom(server_sock, buffer, BUFFER_SIZE, 0,
                             (struct sockaddr *)&client_addr, &addr_len) < 0) {
                    perror("recvfrom() failed");
                    break;
                }
            #endif

            if (strcmp(buffer, "bye") == 0) {
                char goodbye_msg[100];
                sprintf(goodbye_msg, "Goodbye %s", account->username);
                #ifdef _WIN32
                    sendto(server_sock, goodbye_msg, strlen(goodbye_msg) + 1, 0,
                           (struct sockaddr *)&client_addr, addr_len);
                #else
                    sendto(server_sock, goodbye_msg, strlen(goodbye_msg) + 1, 0,
                           (struct sockaddr *)&client_addr, addr_len);
                #endif
                break;
            } else {
                if (!is_alphanumeric(buffer)) {
                    char *error_msg = "Error";
                    #ifdef _WIN32
                        sendto(server_sock, error_msg, strlen(error_msg) + 1, 0,
                               (struct sockaddr *)&client_addr, addr_len);
                    #else
                        sendto(server_sock, error_msg, strlen(error_msg) + 1, 0,
                               (struct sockaddr *)&client_addr, addr_len);
                    #endif
                } else {
                    // Encode new password using SHA256
                    char hex[SHA256_HEX_SIZE];
                    sha256_hex(buffer, strlen(buffer), hex);

                    // Update password in account
                    strcpy(account->password, buffer);
                    save_accounts();

                    #ifdef _WIN32
                        sendto(server_sock, hex, strlen(hex) + 1, 0,
                               (struct sockaddr *)&client_addr, addr_len);
                    #else
                        sendto(server_sock, hex, strlen(hex) + 1, 0,
                               (struct sockaddr *)&client_addr, addr_len);
                    #endif
                }
            }
        }
    }

    // Close socket
    #ifdef _WIN32
        closesocket(server_sock);
        WSACleanup();
    #else
        close(server_sock);
    #endif

    return 0;
}
